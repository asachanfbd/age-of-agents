---
name: whatever
description: A zipped skill.
---

# Zipped
